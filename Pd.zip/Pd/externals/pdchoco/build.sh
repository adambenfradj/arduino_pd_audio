#!/bin/bash
python generate_index.py