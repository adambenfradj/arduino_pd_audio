import os
import re

# ============================================================
# Configuration
# ============================================================

FOLDER = "."

OUTPUT_MD = "index.md"
OUTPUT_PD = "_index.pd"

# Pd index layout
OBJECT_X = 50
START_Y = 50
ROW_GAP = 20

# Default size for non-GOP abstractions
DEFAULT_OBJECT_WIDTH = 80
DEFAULT_OBJECT_HEIGHT = 20

# Description column
MIN_DESCRIPTION_X = 300
DESCRIPTION_MARGIN = 80


# ============================================================
# Get description from help file
# ============================================================

def get_description(filepath):
    """
    Extract:

        Description: Something;

    or:

        Description : Something;

    from the help patch.
    """

    with open(filepath, "r", encoding="utf-8-sig") as f:

        for line in f:

            match = re.search(
                r"Description\s*:\s*(.*)",
                line
            )

            if match:

                description = match.group(1).strip()

                # Remove Pd line continuation
                description = description.replace(
                    " \\",
                    ""
                )

                # Remove trailing semicolon
                if description.endswith(";"):
                    description = description[:-1].strip()

                return description

    return ""


# ============================================================
# Get GOP dimensions from the ACTUAL abstraction
# ============================================================

def get_gop_dimensions(filepath):
    """
    Look for the final #X coords line in the actual
    abstraction .pd file.

    Example:

        #X coords 0 -1 1 1 190 90 1 100 100;

    means:

        width  = 190
        height = 90
        GOP    = 1

    Returns:

        (width, height)

    if GOP is enabled.

    Returns None if the abstraction is not GOP.
    """

    if not os.path.isfile(filepath):
        return None

    last_coords = None

    with open(filepath, "r", encoding="utf-8-sig") as f:

        for line in f:

            line = line.strip()

            if line.startswith("#X coords"):

                last_coords = line

    # No coords line
    if last_coords is None:
        return None

    parts = last_coords.rstrip(";").split()

    # Expected:
    #
    # #X coords X1 Y1 X2 Y2 WIDTH HEIGHT GOP ...
    #
    # 0       1      2  3  4  5  6      7       8

    if len(parts) < 9:
        return None

    try:

        width = float(parts[6])
        height = float(parts[7])
        gop = int(float(parts[8]))

    except (ValueError, IndexError):

        return None

    # GOP flag
    if gop == 0:
        return None

    return width, height


# ============================================================
# Escape Pd text
# ============================================================

def escape_pd_text(text):
    """
    Escape characters that have special meaning in Pd files.

    Pd uses:
        ;  as a message/object terminator
        ,  as a message separator
        \\ as an escape character

    Backslash must be escaped first so that the escapes we add
    below are not themselves modified.
    """

    text = text.replace("\\", "\\\\")
    text = text.replace(";", " \\;")
    text = text.replace(",", " \,")

    return text


# ============================================================
# Find all abstractions
# ============================================================

entries = []

for filename in sorted(os.listdir(FOLDER)):

    if not filename.endswith("-help.pd"):
        continue

    # --------------------------------------------------------
    # Names
    # --------------------------------------------------------

    object_name = filename[:-8]
    display_name = f"pdchoco/{object_name}"

    help_filepath = os.path.join(
        FOLDER,
        filename
    )

    abstraction_filepath = os.path.join(
        FOLDER,
        object_name + ".pd"
    )

    # --------------------------------------------------------
    # Description comes from -help.pd
    # --------------------------------------------------------

    description = get_description(
        help_filepath
    )

    # --------------------------------------------------------
    # GOP comes from the actual abstraction .pd
    # --------------------------------------------------------

    gop_dimensions = get_gop_dimensions(
        abstraction_filepath
    )

    if gop_dimensions is not None:

        width, height = gop_dimensions
        is_gop = True

    else:

        width = DEFAULT_OBJECT_WIDTH
        height = DEFAULT_OBJECT_HEIGHT
        is_gop = False

    # --------------------------------------------------------
    # Store
    # --------------------------------------------------------

    entries.append({
        "name": object_name,
        "display_name": display_name,
        "description": description,
        "width": width,
        "height": height,
        "gop": is_gop,
    })


# ============================================================
# Create Markdown index
# ============================================================

md_lines = [
    "## Abstractions",
    ""
]

for entry in entries:

    if entry["description"]:

        md_lines.append(
            f"- `{entry['display_name']}`: "
            f"{entry['description']}"
        )

    else:

        md_lines.append(
            f"- `{entry['display_name']}`"
        )


with open(
    os.path.join(FOLDER, OUTPUT_MD),
    "w",
    encoding="utf-8"
) as f:

    f.write("\n".join(md_lines))


# ============================================================
# Calculate description column
# ============================================================

if entries:

    widest_object = max(
        entry["width"]
        for entry in entries
    )

    description_x = max(
        MIN_DESCRIPTION_X,
        OBJECT_X + widest_object + DESCRIPTION_MARGIN
    )

else:

    description_x = MIN_DESCRIPTION_X


# ============================================================
# Create Pd index
# ============================================================

pd_lines = [
    "#N canvas 50 50 1400 800 12;"
]

y = START_Y

for entry in entries:

    display_name = entry["display_name"]
    description = entry["description"]

    width = entry["width"]
    height = entry["height"]

    # --------------------------------------------------------
    # Abstraction
    # --------------------------------------------------------

    pd_lines.append(
        f"#X obj "
        f"{OBJECT_X} "
        f"{int(y)} "
        f"{display_name};"
    )

    # --------------------------------------------------------
    # Description
    # --------------------------------------------------------

    if description:

        escaped_description = escape_pd_text(
            description
        )

        pd_lines.append(
            f"#X text "
            f"{int(description_x)} "
            f"{int(y)} "
            f"{escaped_description};"
        )

    # --------------------------------------------------------
    # Next row
    # --------------------------------------------------------

    row_height = max(
        DEFAULT_OBJECT_HEIGHT,
        height
    )

    y += row_height + ROW_GAP


# ============================================================
# Write Pd index
# ============================================================

with open(
    os.path.join(FOLDER, OUTPUT_PD),
    "w",
    encoding="utf-8"
) as f:

    f.write("\n".join(pd_lines))


# ============================================================
# Report
# ============================================================

gop_entries = [
    entry
    for entry in entries
    if entry["gop"]
]

print()
print(
    f"✅ {OUTPUT_MD} created with "
    f"{len(entries)} entries."
)

print(
    f"✅ {OUTPUT_PD} created with "
    f"{len(entries)} abstractions."
)

print(
    f"   {len(gop_entries)} GOP abstractions detected."
)

print()